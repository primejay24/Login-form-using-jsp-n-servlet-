package crud.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Register extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		
		int id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String pwd=request.getParameter("password");
		String company=request.getParameter("company");
		
		
		//pw.println(s1+s2+s3+"Password:"+s4+s5);
		Connection con=null;
        Statement stmt=null;
        String url="jdbc:mysql://localhost:3306/logindemo";
        String username="root";
        String password="root";
       
        try
        {
              Class.forName("com.mysql.jdbc.Driver");
              con = DriverManager.getConnection( url,username,password );
              stmt=con.createStatement();
              int i = stmt.executeUpdate("insert into registration values('"+id+"','"+name+"','"+email+"','"+pwd+"','"+company+"')");
              if(i>0)
              {
               // pw.println("Registered  Successfully");
            	  pw.println("<script type=\"text/javascript\">");
	                pw.println("alert('Registred successfully');");
	                pw.println("</script>");
	                pw.print("<a href='login.jsp'>Go to Home Page</a>"); 
	                
              }
              else
              {
                pw.println("Insert Unsuccessful");
              }
        }
        catch(Exception e)
        {
          pw.println(e);       
        }
       
		
	}

}
