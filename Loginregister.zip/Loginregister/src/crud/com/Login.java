package crud.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Login extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		 String email=request.getParameter("email");
	     String pwd= request.getParameter("password");
	     String query="select * from registration where email=? and password=?"; 
	     PrintWriter pw=response.getWriter();
	     Connection con=null;
	        try  
	        {
	        	Class.forName("com.mysql.jdbc.Driver");
	        	 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/logindemo","root","root");
	        	PreparedStatement ps = con.prepareStatement(query);
	            ps.setString(1, email);
	            ps.setString(2, pwd);
	            ResultSet rs = ps.executeQuery();
	            if(rs.next())
                {
	            	 pw.println("Login successfully");
	            	//pw.println("<script type=\"text/javascript\">");
	               // pw.println("alert('You want to update record');");
	               // pw.println("</script>");
	            	 pw.print("<br><a href=\"update.jsp\"><button type=\"button\">Update</button></a>");
                    
                    
                }else
                {
                    pw.println("Incorrect Details");
                }
	        	
	        }
	        catch(Exception e)
	        {
	        	e.printStackTrace();
	        }
	        HttpSession session = request.getSession();
	        session.setAttribute("Mail", email);
	        session.setAttribute("Password",pwd);
	       // response.sendRedirect("update.jsp");
	        
	        
	       
	}

}
